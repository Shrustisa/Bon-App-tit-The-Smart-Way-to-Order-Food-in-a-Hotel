from django import forms
from .models import Dish, TableOrder, OrderItem

class DishForm(forms.ModelForm):
    class Meta:
        model = Dish
        fields = ["name", "ingredients", "price"]
        widgets = {
            "name": forms.TextInput(attrs={"class": "form-control", "placeholder": "Dish name"}),
            "ingredients": forms.Textarea(attrs={"class": "form-control", "rows": 3, "placeholder": "Ingredients..."}),
            "price": forms.NumberInput(attrs={"class": "form-control", "step": "0.01"}),
        }


class TableOrderForm(forms.ModelForm):
    class Meta:
        model = TableOrder
        fields = ["table_number", "status", "notes"]
        widgets = {
            "table_number": forms.NumberInput(attrs={"class": "form-control", "min": 1}),
            "status": forms.Select(attrs={"class": "form-select"}),
            "notes": forms.TextInput(attrs={"class": "form-control", "placeholder": "Optional notes"}),
        }

# forms.py
from django import forms
from .models import TableOrder, OrderItem

class OrderItemForm(forms.ModelForm):
    # Optional on the form
    unit_price = forms.DecimalField(
        required=False, max_digits=10, decimal_places=2,
        widget=forms.NumberInput(attrs={"class": "form-control", "step": "0.01"})
    )

    class Meta:
        model = OrderItem
        fields = ["dish", "quantity", "unit_price"]
        widgets = {
            "dish": forms.Select(attrs={"class": "form-select"}),
            "quantity": forms.NumberInput(attrs={"class": "form-control", "min": 1}),
        }

    def clean(self):
        cleaned = super().clean()
        dish = cleaned.get("dish")
        qty = cleaned.get("quantity") or 1
        price = cleaned.get("unit_price")

        # Raw form input (string) to detect if user actually typed a price
        raw_price = (self.data.get(f"{self.prefix}-unit_price", "") or "").strip()

        # When a dish is chosen and user didn't supply a price -> default from dish
        # Covers: new rows, and dish changed on existing rows
        if dish and (raw_price == "" or price is None):
            cleaned["unit_price"] = dish.price

        if dish and (qty is None or qty < 1):
            self.add_error("quantity", "Quantity must be at least 1.")

        # If the row is entirely empty (no dish), the inline formset will ignore it
        return cleaned
