from django.apps import AppConfig


class RestaurantmanagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'RestaurantManagement'
