from django.urls import path
from . import views

app_name = "restaurant"

urlpatterns = [
    # Dishes (Menu)
    path("dishes/", views.dish_list, name="dish_list"),
    path("dishes/create/", views.dish_create, name="dish_create"),
    path("dishes/<int:pk>/edit/", views.dish_update, name="dish_update"),
    path("dishes/<int:pk>/delete/", views.dish_delete, name="dish_delete"),

    # Orders
    path("orders/", views.order_list, name="order_list"),
    path("orders/create/", views.order_create, name="order_create"),
    path("orders/<int:pk>/edit/", views.order_update, name="order_update"),
    path("orders/<int:pk>/delete/", views.order_delete, name="order_delete"),
]
