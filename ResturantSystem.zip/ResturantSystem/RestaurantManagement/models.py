from decimal import Decimal
from django.db import models
from django.utils import timezone

class Dish(models.Model):
    name = models.CharField(max_length=200)
    ingredients = models.TextField(blank=True)
    price = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return f"{self.name} ({self.price})"


class TableOrder(models.Model):
    STATUS_CHOICES = [
        ("OPEN", "Open"),
        ("PAID", "Paid"),
        ("CANCELLED", "Cancelled"),
    ]
    table_number = models.PositiveIntegerField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default="OPEN")
    notes = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Order #{self.pk or '—'} | Table {self.table_number}"

    @property
    def total(self):
        total = Decimal("0.00")
        for it in self.items.all():
            total += (it.quantity or 0) * (it.unit_price or Decimal("0.00"))
        return total


class OrderItem(models.Model):
    order = models.ForeignKey(TableOrder, on_delete=models.CASCADE, related_name="items")
    dish = models.ForeignKey(Dish, on_delete=models.PROTECT, related_name="order_items")
    quantity = models.PositiveIntegerField(default=1)
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)

    class Meta:
        ordering = ["pk"]

    def __str__(self):
        return f"{self.dish.name} x {self.quantity}"
