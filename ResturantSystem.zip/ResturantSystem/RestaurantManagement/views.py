from django.db import transaction
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from .models import *
from .forms import *

# --------- Dish CRUD (Menu) ---------

def dish_list(request):
    search = request.GET.get("search", "").strip()
    qs = Dish.objects.all()
    if search:
        qs = qs.filter(Q(name__icontains=search) | Q(ingredients__icontains=search))
    return render(request, "restaurant/dish_list.html", {"dishes": qs, "search": search})

def dish_create(request):
    if request.method == "POST":
        form = DishForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("restaurant:dish_list")
    else:
        form = DishForm()
    return render(request, "restaurant/dish_form.html", {"form": form, "title": "Add Dish"})

def dish_update(request, pk):
    dish = get_object_or_404(Dish, pk=pk)
    if request.method == "POST":
        form = DishForm(request.POST, instance=dish)
        if form.is_valid():
            form.save()
            return redirect("restaurant:dish_list")
    else:
        form = DishForm(instance=dish)
    return render(request, "restaurant/dish_form.html", {"form": form, "title": "Edit Dish"})

def dish_delete(request, pk):
    dish = get_object_or_404(Dish, pk=pk)
    if request.method == "POST":
        dish.delete()
        return redirect("restaurant:dish_list")
    return render(request, "restaurant/dish_confirm_delete.html", {"dish": dish})


# --------- Order CRUD (with items) ---------



from django.db import transaction
from django.forms import inlineformset_factory
from django.shortcuts import render, redirect, get_object_or_404
from django.db.models import Q, Prefetch

from .models import TableOrder, OrderItem
from .forms import TableOrderForm, OrderItemForm

def _make_items_formset(extra: int):
    """Create a fresh inline formset factory with the requested `extra` rows."""
    extra = max(1, min(int(extra or 1), 20))  # guardrails (1..20)
    return inlineformset_factory(
        parent_model=TableOrder,
        model=OrderItem,
        form=OrderItemForm,
        fields=["dish", "quantity", "unit_price"],
        extra=extra,
        can_delete=True,
    )

def order_list(request):
    search = request.GET.get("search", "").strip()
    status = request.GET.get("status", "").strip()
    qs = (
        TableOrder.objects
        .prefetch_related(Prefetch("items", queryset=OrderItem.objects.select_related("dish")))
        .all()
    )
    if search:
        qs = qs.filter(
            Q(table_number__icontains=search) |
            Q(items__dish__name__icontains=search)
        ).distinct()
    if status:
        qs = qs.filter(status=status)

    return render(request, "restaurant/order_list.html", {
        "orders": qs, "search": search, "status": status
    })

@transaction.atomic
def order_create(request):
    extra = request.GET.get("extra", 1)
    ItemsFormSet = _make_items_formset(extra)

    if request.method == "POST":
        order_form = TableOrderForm(request.POST)
        if order_form.is_valid():
            order = order_form.save()  # create the parent first
            formset = ItemsFormSet(request.POST, instance=order)  # <-- bind to parent
            if formset.is_valid():
                formset.save()
                return redirect("restaurant:order_list")
            else:
                # IMPORTANT: keep the same instance so errors show against those forms
                pass
        else:
            # Bind formset even if order form invalid so you see errors properly
            formset = ItemsFormSet(request.POST)  # no instance yet
    else:
        order_form = TableOrderForm()
        formset = ItemsFormSet(instance=TableOrder())  # new blank parent instance

    return render(request, "restaurant/order_form.html", {
        "order_form": order_form,
        "formset": formset,
        "title": "Create Order",
    })


# views.py (update action)
from django.db import transaction
from django.forms import inlineformset_factory
from django.shortcuts import render, redirect, get_object_or_404
from .models import TableOrder, OrderItem
from .forms import TableOrderForm, OrderItemForm

def _make_items_formset(extra: int):
    extra = max(1, min(int(extra or 1), 20))
    return inlineformset_factory(
        TableOrder, OrderItem,
        form=OrderItemForm,
        fields=["dish", "quantity", "unit_price"],
        can_delete=True,
        extra=extra,
    )

@transaction.atomic
def order_update(request, pk):
    extra = request.GET.get("extra", 1)
    ItemsFormSet = _make_items_formset(extra)

    order = get_object_or_404(TableOrder, pk=pk)
    if request.method == "POST":
        order_form = TableOrderForm(request.POST, instance=order)
        formset = ItemsFormSet(request.POST, instance=order)  # <-- bind to parent
        if order_form.is_valid() and formset.is_valid():
            order_form.save()

            # Save with commit=False so we can enforce FK and any last defaults
            instances = formset.save(commit=False)
            # Deleted rows
            for obj in formset.deleted_objects:
                obj.delete()
            # New/changed rows
            for obj in instances:
                obj.order = order  # (usually set by instance=order, but safe)
                # unit_price already defaulted in form.clean()
                obj.save()
            # IMPORTANT: save many-to-manys if used (not needed here)
            formset.save_m2m()

            return redirect("restaurant:order_list")
    else:
        order_form = TableOrderForm(instance=order)
        formset = ItemsFormSet(instance=order)

    return render(request, "restaurant/order_form.html", {
        "order_form": order_form,
        "formset": formset,
        "title": f"Edit Order #{order.pk}",
    })


@transaction.atomic
def order_delete(request, pk):
    order = get_object_or_404(TableOrder, pk=pk)
    if request.method == "POST":
        order.delete()
        return redirect("restaurant:order_list")
    return render(request, "restaurant/order_confirm_delete.html", {"order": order})
